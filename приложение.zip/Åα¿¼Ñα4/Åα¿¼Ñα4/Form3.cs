﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пример4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = System.Convert.ToString(System.Convert.ToInt32(textBox1.Text) + System.Convert.ToInt32(textBox2.Text));
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label1.Text = "";
        }

        private void сложитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Text = System.Convert.ToString(System.Convert.ToInt32(textBox1.Text) + System.Convert.ToInt32(textBox2.Text));
        }

        private void вычестьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Text = System.Convert.ToString(System.Convert.ToInt32(textBox1.Text) - System.Convert.ToInt32(textBox2.Text));
        }

        private void умножитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Text = System.Convert.ToString(System.Convert.ToInt32(textBox1.Text) * System.Convert.ToInt32(textBox2.Text));
        }

        private void разделитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Text = System.Convert.ToString(System.Convert.ToInt32(textBox1.Text) / System.Convert.ToInt32(textBox2.Text));
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch;
            ch = e.KeyChar;
            string digit;
            digit = "0123456789";
            if (System.Char.IsControl(e.KeyChar)) return;
            if (digit.IndexOf(System.Convert.ToString(ch)) == -1) e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch;
            ch = e.KeyChar;
            string digit;
            digit = "0123456789";
            if (System.Char.IsControl(e.KeyChar)) return;
            if (digit.IndexOf(System.Convert.ToString(ch)) == -1) e.Handled = true;
        }
    }
}
