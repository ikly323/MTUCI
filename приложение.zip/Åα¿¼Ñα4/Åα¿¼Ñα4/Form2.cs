﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пример4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Font f1 = new Font("Arial", 20);
            Font f2 = new Font("Microsoft Sans Serif", 9);
            if (button1.Text=="Для простых")
            {
                richTextBox1.Font = f2;
                button1.Text = "Для слепых";
            }
            else
            {
                richTextBox1.Font = f1;
                button1.Text = "Для простых";
            }
        }

        private void отобразитьСтихиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (отобразитьСтихиToolStripMenuItem.Text=="Отобразить стихи")
            {
                richTextBox1.Visible = true;
                button1.Visible = true;
                отобразитьСтихиToolStripMenuItem.Text = "Скрыть стихи";
                редактироватьСтихиToolStripMenuItem.Enabled = true;
            }
            else
            {
                richTextBox1.Visible = false;
                button1.Visible = false;
                отобразитьСтихиToolStripMenuItem.Text = "Отобразить стихи";
                редактироватьСтихиToolStripMenuItem.Enabled = false;
            }
        }

        private void редактироватьСтихиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Enabled = true;
            
        }
    }
}
