﻿namespace Пример4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.отобразитьСтихиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьСтихиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Location = new System.Drawing.Point(318, 80);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(423, 355);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "Можно часто увлекаться\nНо один лишь раз любить\nНенадолго повстречаться\nЧтоб навек" +
    "и не забыть";
            this.richTextBox1.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(69, 233);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 44);
            this.button1.TabIndex = 1;
            this.button1.Text = "Для простых";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отобразитьСтихиToolStripMenuItem,
            this.редактироватьСтихиToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(188, 70);
            // 
            // отобразитьСтихиToolStripMenuItem
            // 
            this.отобразитьСтихиToolStripMenuItem.Name = "отобразитьСтихиToolStripMenuItem";
            this.отобразитьСтихиToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.отобразитьСтихиToolStripMenuItem.Text = "Отобразить стихи";
            this.отобразитьСтихиToolStripMenuItem.Click += new System.EventHandler(this.отобразитьСтихиToolStripMenuItem_Click);
            // 
            // редактироватьСтихиToolStripMenuItem
            // 
            this.редактироватьСтихиToolStripMenuItem.Enabled = false;
            this.редактироватьСтихиToolStripMenuItem.Name = "редактироватьСтихиToolStripMenuItem";
            this.редактироватьСтихиToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.редактироватьСтихиToolStripMenuItem.Text = "Редактировать стихи";
            this.редактироватьСтихиToolStripMenuItem.Click += new System.EventHandler(this.редактироватьСтихиToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(798, 506);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem отобразитьСтихиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьСтихиToolStripMenuItem;
    }
}