﻿namespace Пример4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ивановToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.петровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сидоровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ивановToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.петровToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сидоровToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.отобразитьКалендарьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.формаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.форма2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.форма3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.contextMenuStrip3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.textBox1.Location = new System.Drawing.Point(205, 170);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(218, 20);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.ContextMenuStrip = this.contextMenuStrip2;
            this.textBox2.Location = new System.Drawing.Point(205, 197);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(218, 20);
            this.textBox2.TabIndex = 1;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ивановToolStripMenuItem,
            this.петровToolStripMenuItem,
            this.сидоровToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(123, 70);
            // 
            // ивановToolStripMenuItem
            // 
            this.ивановToolStripMenuItem.Name = "ивановToolStripMenuItem";
            this.ивановToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ивановToolStripMenuItem.Text = "Иванов";
            this.ивановToolStripMenuItem.Click += new System.EventHandler(this.ивановToolStripMenuItem_Click);
            // 
            // петровToolStripMenuItem
            // 
            this.петровToolStripMenuItem.Name = "петровToolStripMenuItem";
            this.петровToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.петровToolStripMenuItem.Text = "Петров";
            this.петровToolStripMenuItem.Click += new System.EventHandler(this.петровToolStripMenuItem_Click);
            // 
            // сидоровToolStripMenuItem
            // 
            this.сидоровToolStripMenuItem.Name = "сидоровToolStripMenuItem";
            this.сидоровToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.сидоровToolStripMenuItem.Text = "Сидоров";
            this.сидоровToolStripMenuItem.Click += new System.EventHandler(this.сидоровToolStripMenuItem_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ивановToolStripMenuItem1,
            this.петровToolStripMenuItem1,
            this.сидоровToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(123, 70);
            // 
            // ивановToolStripMenuItem1
            // 
            this.ивановToolStripMenuItem1.Name = "ивановToolStripMenuItem1";
            this.ивановToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ивановToolStripMenuItem1.Text = "Иванов";
            this.ивановToolStripMenuItem1.Click += new System.EventHandler(this.ивановToolStripMenuItem1_Click);
            // 
            // петровToolStripMenuItem1
            // 
            this.петровToolStripMenuItem1.Name = "петровToolStripMenuItem1";
            this.петровToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.петровToolStripMenuItem1.Text = "Петров";
            this.петровToolStripMenuItem1.Click += new System.EventHandler(this.петровToolStripMenuItem1_Click);
            // 
            // сидоровToolStripMenuItem1
            // 
            this.сидоровToolStripMenuItem1.Name = "сидоровToolStripMenuItem1";
            this.сидоровToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.сидоровToolStripMenuItem1.Text = "Сидоров";
            this.сидоровToolStripMenuItem1.Click += new System.EventHandler(this.сидоровToolStripMenuItem1_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(531, 170);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 4;
            this.monthCalendar1.Visible = false;
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отобразитьКалендарьToolStripMenuItem});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(199, 26);
            // 
            // отобразитьКалендарьToolStripMenuItem
            // 
            this.отобразитьКалендарьToolStripMenuItem.Name = "отобразитьКалендарьToolStripMenuItem";
            this.отобразитьКалендарьToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.отобразитьКалендарьToolStripMenuItem.Text = "Отобразить календарь";
            this.отобразитьКалендарьToolStripMenuItem.Click += new System.EventHandler(this.отобразитьКалендарьToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.формаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1274, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.открытьToolStripMenuItem.Text = "Открыть";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.открытьToolStripMenuItem_Click);
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.сохранитьToolStripMenuItem.Text = "Сохранить";
            this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.сохранитьToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "файлы JPEG|*.jpg|файлы BMP|*.bmp|все файлы|*.*";
            this.openFileDialog1.Title = "Выберите имя графического файла";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "файлы JPEG|*.jpg|файлы BMP|*.bmp|все файлы|*.*";
            this.saveFileDialog1.Title = "Выберите имя сохраняемого файла";
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(775, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 7;
            // 
            // формаToolStripMenuItem
            // 
            this.формаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.форма2ToolStripMenuItem,
            this.форма3ToolStripMenuItem});
            this.формаToolStripMenuItem.Name = "формаToolStripMenuItem";
            this.формаToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.формаToolStripMenuItem.Text = "Форма";
            // 
            // форма2ToolStripMenuItem
            // 
            this.форма2ToolStripMenuItem.Name = "форма2ToolStripMenuItem";
            this.форма2ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.форма2ToolStripMenuItem.Text = "Форма2";
            this.форма2ToolStripMenuItem.Click += new System.EventHandler(this.форма2ToolStripMenuItem_Click);
            // 
            // форма3ToolStripMenuItem
            // 
            this.форма3ToolStripMenuItem.Name = "форма3ToolStripMenuItem";
            this.форма3ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.форма3ToolStripMenuItem.Text = "Форма3";
            this.форма3ToolStripMenuItem.Click += new System.EventHandler(this.форма3ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1274, 463);
            this.ContextMenuStrip = this.contextMenuStrip3;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DoubleClick += new System.EventHandler(this.Form1_DoubleClick);
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.contextMenuStrip3.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ивановToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem петровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сидоровToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem ивановToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem петровToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сидоровToolStripMenuItem1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem отобразитьКалендарьToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem формаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem форма2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem форма3ToolStripMenuItem;
    }
}

