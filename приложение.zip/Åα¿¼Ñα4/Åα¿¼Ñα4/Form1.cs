﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пример4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ивановToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = ивановToolStripMenuItem.Text;
        }

        private void петровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = петровToolStripMenuItem.Text;
        }

        private void сидоровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = сидоровToolStripMenuItem.Text;
        }

        private void ивановToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox2.Text = ивановToolStripMenuItem1.Text;
        }

        private void петровToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox2.Text = петровToolStripMenuItem1.Text;
        }

        private void сидоровToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox2.Text = сидоровToolStripMenuItem1.Text;
        }

        private void отобразитьКалендарьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (отобразитьКалендарьToolStripMenuItem.Text=="Отобразить календарь")
            {
                monthCalendar1.Visible = true;
                отобразитьКалендарьToolStripMenuItem.Text = "Скрыть календарь";
            }
            else
            {
                monthCalendar1.Visible = false;
                отобразитьКалендарьToolStripMenuItem.Text = "Отобразить календарь";
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Вы выбрали файл " + openFileDialog1.FileName, "Открытие файла", MessageBoxButtons.OK);
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Вы сохраняете файл под именем " + saveFileDialog1.FileName, "Сохранение файла", MessageBoxButtons.OK);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            DialogResult rez;
            rez=MessageBox.Show("Выберите действие", "Выбор действия", MessageBoxButtons.OKCancel);
            if (rez == DialogResult.OK) label1.Text = "Вы нажали ОК";
            else label1.Text = "Вы нажали Cancel";
        }

        private void форма2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
        }

        private void форма3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f3 = new Form3();
            f3.Show();
        }
    }
}
