﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пример1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Главная форма";
            label4.Text = "";
            
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            this.Text = "Первая форма";
            button1.Visible = false;
        }

        private void Form1_CursorChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Text = "Кнопка нажата";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            /*try
            {
                textBox3.Text = System.Convert.ToString(System.Convert.ToInt32(textBox1.Text) + System.Convert.ToInt32(textBox2.Text));
            }
                catch
                {
                MessageBox.Show("В поля можно вводить только целые числа", "Ошибка", MessageBoxButtons.OK);
            }*/

            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch;
            ch = e.KeyChar;
            string digit;
            digit = "0123456789";
            if (System.Char.IsControl(e.KeyChar))
            {
                return;
            }
            if (digit.IndexOf(System.Convert.ToString(ch))==-1)
            {
                e.Handled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch;
            ch = e.KeyChar;
            string digit;
            digit = "0123456789";
            if (System.Char.IsControl(e.KeyChar))
            {
                return;
            }
            if (digit.IndexOf(System.Convert.ToString(ch)) == -1)
            {
                e.Handled = true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true) label4.Text = "Флажок нажат";
            else label4.Text = "Флажок отпущен";

        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            сохранитьToolStripMenuItem.Enabled = true;
            сохранитьКакToolStripMenuItem.Enabled = true;
            закрытьToolStripMenuItem.Enabled = true;
            openFileDialog1.ShowDialog();
        }

        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            сохранитьToolStripMenuItem.Enabled = false;
            сохранитьКакToolStripMenuItem.Enabled = false;
            закрытьToolStripMenuItem.Enabled = false;
        }

        private void втораяФормаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            textBox1.Text = toolStripMenuItem2.Text;
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            textBox1.Text = toolStripMenuItem3.Text;
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            textBox1.Text = toolStripMenuItem4.Text;
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            textBox1.Text = toolStripMenuItem5.Text;
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            textBox2.Text = toolStripMenuItem6.Text;
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            textBox2.Text = toolStripMenuItem7.Text;
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            textBox3.Text = toolStripMenuItem8.Text;
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            textBox2.Text = toolStripMenuItem9.Text;
        }

        private void форма2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
        }

        private void форма3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f3 = new Form3();
            f3.Show();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Вы выбрали файл " + openFileDialog1.FileName, "Выбор файла", MessageBoxButtons.OK);
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Вы выбрали файл " + saveFileDialog1.FileName, "Выбор файла", MessageBoxButtons.OK);
        }
    }
}
