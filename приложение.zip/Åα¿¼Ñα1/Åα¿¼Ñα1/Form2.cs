﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пример1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label2.Text = "Выбран элемент " + comboBox1.SelectedItem;
            label3.Text = "Индекс выбранного элемента " + System.Convert.ToString(comboBox1.SelectedIndex);
           switch (comboBox1.SelectedIndex)
            {
                case 0:
                    {
                        label4.Text = "Выбрана первая строка";
                        break;
                    }
                case 1:
                    {
                        label4.Text = "Выбрана вторая строка";
                        break;
                    }
                case 2:
                    {
                        label4.Text = "Выбрана третья строка";
                        break;
                    }
                case 3:
                    {
                        label4.Text = "Выбрана четвертая строка";
                        break;
                    }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Пять");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove("Петров");
        }
    }
}
