﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пример1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void отобразитьКалендарьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (отобразитьКалендарьToolStripMenuItem.Text=="Отобразить календарь")
            {
                dateTimePicker1.Visible = true;
                отобразитьКалендарьToolStripMenuItem.Text = "Скрыть календарь";
            }
            else
            {
                dateTimePicker1.Visible = false;
                отобразитьКалендарьToolStripMenuItem.Text = "Отобразить календарь";
            }
        }

        private void Form3_DoubleClick(object sender, EventArgs e)
        {
            DialogResult rez;
            rez=MessageBox.Show("Выбрать действие", "Выбрать действие", MessageBoxButtons.OKCancel);
            if (rez == DialogResult.OK) label1.Text = "Нажата кнопка ОК";
            else label1.Text = "Нажата кнопка Cancel";
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
