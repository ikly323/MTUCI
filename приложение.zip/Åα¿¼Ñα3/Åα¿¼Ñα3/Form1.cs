﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пример3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int combo_index = 1;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label2.Text = "Выбрано значение " + comboBox1.SelectedItem;
            label3.Text = "Его индекс " + System.Convert.ToString(comboBox1.SelectedIndex);
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    {
                        label4.Text = "Выбран первый пункт";
                        break;
                    }
                case 1:
                    {
                        label4.Text = "Выбран второй пункт";
                        break;
                    }
                case 2:
                    {
                        label4.Text = "Выбран третий пункт";
                        break;
                    }
                case 3:
                    {
                        label4.Text = "Выбран четвертый пункт";
                        break;
                    }

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Add(System.Convert.ToString(combo_index));
            combo_index += 1;
        }

        private void delerte_button_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove("Сидоров");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            listBox1.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text=="Выбрать число")
            {
                label1.Visible = true;
                comboBox1.Visible = true;
                button3.Text = "Скрыть выбор";
            }
            else
            {
                label1.Visible = false;
                comboBox1.Visible = false;
                button3.Text = "Выбрать число";
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true) label2.Text = "Флажок установлен";
            else label2.Text = "Флажок снят";
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            сохранитьToolStripMenuItem.Enabled = true;
            сохранитьКакToolStripMenuItem.Enabled = true;
            закрытьToolStripMenuItem.Enabled = true;
        }

        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            сохранитьToolStripMenuItem.Enabled = false;
            сохранитьКакToolStripMenuItem.Enabled = false;
            закрытьToolStripMenuItem.Enabled = false;
        }

        private void форма2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Font f1 = new Font("Arial",20);
            Font f2 = new Font("Microsoft Sans Serif",8);
            if (button4.Text=="Для слабовидящих")
            {
                richTextBox1.Font = f1;
                button4.Text = "Для простых";
            }
            else
            {
                richTextBox1.Font = f2;
                button4.Text = "Для слабовидящих";
            }


            
            
        }

        private void отобразитьСтихиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (отобразитьСтихиToolStripMenuItem.Text=="Отобразить стихи")
            {
                richTextBox1.Visible=true;
                button4.Visible = true;
                отобразитьСтихиToolStripMenuItem.Text = "Скрыть стихи";
                редактироватьСтихиToolStripMenuItem.Enabled = true;
            }
            else
            {
                richTextBox1.Visible = false;
                button4.Visible = false;
                отобразитьСтихиToolStripMenuItem.Text = "Отобразить стихи";
                редактироватьСтихиToolStripMenuItem.Enabled = false;
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void редактироватьСтихиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Enabled = true;
            button4.Enabled = true;
        }
    }
}
