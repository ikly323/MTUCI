﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Проект2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label2.Text = "Выбран элемент " + comboBox1.SelectedValue;
            label3.Text = "Его индекс " + System.Convert.ToString(comboBox1.SelectedIndex);
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    {
                        label4.Text = "Выбрали значение один";
                        break;
                    }
                case 1:
                    {
                        label4.Text = "Выбрали значение два";
                        break;
                    }
                case 2:
                    {
                        label4.Text = "Выбрали значение три";
                        break;
                    }
                case 3:
                    {
                        label4.Text = "Выбрали значение четыре";
                        break;
                    }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Add("пять");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove("Петров");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            listBox1.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text=="Выбрать число")
            {
                label1.Visible = true;
                comboBox1.Visible = true;
                button4.Text = "Скрыть выбор";
            }
            else
            {
                label1.Visible = false;
                comboBox1.Visible = false;
                button4.Text = "Выбрать число";
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true) label2.Text = "Флажок установлен";
            else label2.Text = "Флажок снят";
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            открытьToolStripMenuItem.Enabled = true;
            сохранитьToolStripMenuItem.Enabled = true;
            закрытьToolStripMenuItem.Enabled = true;
        }

        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            открытьToolStripMenuItem.Enabled = false;
            сохранитьToolStripMenuItem.Enabled = false;
            закрытьToolStripMenuItem.Enabled = false;
        }

        private void форма2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
        }

        private void открытьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (открытьToolStripMenuItem1.Text == "Открыть") открытьToolStripMenuItem1.Text = "Закрыть";
            else открытьToolStripMenuItem1.Text = "Открыть";
        }

        private void ивановToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = ивановToolStripMenuItem.Text;
        }

        private void петровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = петровToolStripMenuItem.Text;
        }

        private void сидоровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = сидоровToolStripMenuItem.Text;
        }

        private void ивановToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox2.Text = ивановToolStripMenuItem1.Text;
        }

        private void петровToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox2.Text = петровToolStripMenuItem1.Text;
        }

        private void сидоровToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox2.Text = сидоровToolStripMenuItem1.Text;
        }

        private void отобразитьКалендарьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (отобразитьКалендарьToolStripMenuItem.Text=="Отобразить календарь")
            {
                monthCalendar1.Visible = true;
                отобразитьКалендарьToolStripMenuItem.Text = "Скрыть календарь";
            }
            else
            {
                monthCalendar1.Visible = false;
                отобразитьКалендарьToolStripMenuItem.Text = "Отобразить календарь";
            }
        }

        private void отобразитьКалендарьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (отобразитьКалендарьToolStripMenuItem.Text=="Отобразить календарь")
            {
                monthCalendar1.Visible = true;
                отобразитьКалендарьToolStripMenuItem.Text = "Скрыть календарь";
            }
            else
            {
                monthCalendar1.Visible = false;
                отобразитьКалендарьToolStripMenuItem.Text = "Отобразить календарь";
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Вы выбрали файл " + openFileDialog1.FileName, "Выбор файла", MessageBoxButtons.OK);
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Вы выбрали файл " + saveFileDialog1.FileName, "Сохранение файла", MessageBoxButtons.OK);
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            DialogResult rez;
            rez=MessageBox.Show("Сделайте выбор", "Выбор", MessageBoxButtons.OKCancel);
            if (rez == DialogResult.OK) label5.Text = "Вы нажали ОК";
            else label5.Text = "Вы нажали Cancel";
        }
    }
}
