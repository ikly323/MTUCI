﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Graphics g;
        int p1 = 0, p2 = 0;
        Point[] masOfPoints;
        Int32 numOfPoints;
        Color c1;
        int ColorPriznak;
        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            g.DrawLine(new Pen(Color.Red, 5), 10, 10, 500, 500);
            p1 = 1;
        }

        private void button1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Point[] points ={new Point(10,10), new Point(10,100), 
                               new Point(200,50), new Point(250,300)};
            g.DrawLines(new Pen(Color.Plum, 5), points);
            p2 = 1;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (p1 == 1) g.DrawLine(new Pen(Color.Red, 5), 10, 10, 500, 500);
            if (p2 == 1)
            {
                Point[] points ={new Point(10,10), new Point(10,100), 
                               new Point(200,50), new Point(250,300)};
                g.DrawLines(new Pen(Color.Plum, 5), points);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            g.DrawRectangle(new Pen(Color.Blue, 3), 10, 10, 200, 200);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            g.FillRectangle(new SolidBrush(Color.Yellow), 20, 20, 200, 200);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            g.DrawEllipse(new Pen(Color.Violet, 4), 30, 30, 150, 150);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult dr;
            Color c2;
            dr = colorDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                c2 = colorDialog1.Color;
                g.FillEllipse(new SolidBrush(c2), 45, 45, 200, 200);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            HatchBrush hb;
            hb = new HatchBrush(HatchStyle.Cross,
                Color.Black, Color.Red);
            g.FillEllipse(hb, 50, 50, 100, 100);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Point[] points ={new Point(10,10), new Point(10,100), 
                               new Point(200,50), new Point(250,300),new Point(320,320)};
            g.DrawPolygon(new Pen(Color.Blue, 6), points);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Point[] points ={new Point(10,10), new Point(100,100), 
                               new Point(200,200), new Point(250,300),new Point(320,320)};
            g.FillPolygon(new SolidBrush(Color.BlueViolet), points);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Point[] points ={new Point(10,10), new Point(10,100), 
                               new Point(200,50), new Point(250,300),
                               new Point(320,320),new Point(400,400)};
            g.DrawCurve(new Pen(Color.DarkBlue, 5), points, 0.5f);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            g.Clear(this.BackColor);
            Point[] points ={new Point(10,10), new Point(10,100), 
                               new Point(200,50), new Point(250,300),
                               new Point(320,320),new Point(400,400)};
            g.DrawCurve(new Pen(Color.DarkBlue, 5), points, trackBar1.Value);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Point[] points ={new Point(10,10), new Point(10,100), 
                               new Point(200,50), new Point(250,300),
                               new Point(320,320),new Point(400,400)};
            g.DrawCurve(new Pen(Color.DarkBlue, 10), points, 0.5f);
            g.DrawCurve(new Pen(Color.Red, 5), points, 2, 3, 0.5f);
        }

        private void button11_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Rectangle p = new Rectangle(e.X, e.Y, 2, 2);
                g.FillEllipse(new SolidBrush(Color.Blue), p);
                Point newPoint = new Point(e.X, e.Y);
                numOfPoints = numOfPoints + 1;
                Array.Resize(ref masOfPoints, numOfPoints);
                masOfPoints[numOfPoints - 1] = newPoint;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            g.DrawCurve(new Pen(Color.Red, 5), masOfPoints);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            g.Clear(this.BackColor);
            numOfPoints = 0;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            g.Clear(this.BackColor);
            g.DrawCurve(new Pen(Color.Red, 5), masOfPoints, trackBar2.Value);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Pen gp = new Pen(Color.Green, 4);
            g.DrawBezier(gp, 10, 100, 30, 55, 50, 85, 70, 400);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Pen gp = new Pen(c1, 5);
            Point[] p2 ={new Point(10,10),new Point(10,100),
                           new Point(200,250), new Point(250,300)};
            g.DrawClosedCurve(gp, p2);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Point[] p2 ={new Point(25,25),new Point(25,140),
                           new Point(220,286), new Point(330,380)};
            g.FillClosedCurve(new SolidBrush(c1), p2);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            DialogResult dr;
            dr = colorDialog1.ShowDialog();
            if (dr == DialogResult.OK) c1 = colorDialog1.Color;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            g.DrawPie(new Pen(c1, 5), 10, 10, 300, 400, 20, 60);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            ColorPriznak = 1;
            g.DrawPie(new Pen(Color.Indigo, 4), 10, 10, 200, 200, 0, 90);
            g.DrawPie(new Pen(Color.OrangeRed, 4), 10, 10, 200, 200, 90, 90);
            g.DrawPie(new Pen(Color.SkyBlue, 4), 10, 10, 200, 200, 180, 90);
            g.DrawPie(new Pen(Color.Yellow, 4), 10, 10, 200, 200, 270, 90);
            this.ContextMenuStrip = contextMenuStrip1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (ColorPriznak)
            {
                case 1:
                    {
                        g.DrawPie(new Pen(Color.Indigo, 4), 10, 10, 200, 200, 0, 90);
                        g.DrawPie(new Pen(Color.OrangeRed, 4), 10, 10, 200, 200, 90, 90);
                        g.DrawPie(new Pen(Color.SkyBlue, 4), 10, 10, 200, 200, 180, 90);
                        g.DrawPie(new Pen(Color.Yellow, 4), 10, 10, 200, 200, 270, 90);
                        break;
                    }
                case 2:
                    {
                        g.DrawPie(new Pen(Color.OrangeRed, 4), 10, 10, 200, 200, 0, 90);
                        g.DrawPie(new Pen(Color.SkyBlue, 4), 10, 10, 200, 200, 90, 90);
                        g.DrawPie(new Pen(Color.Yellow, 4), 10, 10, 200, 200, 180, 90);
                        g.DrawPie(new Pen(Color.Indigo, 4), 10, 10, 200, 200, 270, 90);
                        break;
                    }
                case 3:
                    {
                        g.DrawPie(new Pen(Color.SkyBlue, 4), 10, 10, 200, 200, 0, 90);
                        g.DrawPie(new Pen(Color.Yellow, 4), 10, 10, 200, 200, 90, 90);
                        g.DrawPie(new Pen(Color.Indigo, 4), 10, 10, 200, 200, 180, 90);
                        g.DrawPie(new Pen(Color.OrangeRed, 4), 10, 10, 200, 200, 270, 90);
                        break;
                    }
                case 4:
                    {
                        g.DrawPie(new Pen(Color.Yellow, 4), 10, 10, 200, 200, 0, 90);
                        g.DrawPie(new Pen(Color.Indigo, 4), 10, 10, 200, 200, 90, 90);
                        g.DrawPie(new Pen(Color.OrangeRed, 4), 10, 10, 200, 200, 180, 90);
                        g.DrawPie(new Pen(Color.SkyBlue, 4), 10, 10, 200, 200, 270, 90);
                        break;
                    }
                    
            }
                    ColorPriznak = ColorPriznak + 1;
                    if (ColorPriznak == 5) ColorPriznak = 1;
        }

        private void менятьЦветаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (менятьЦветаToolStripMenuItem.Text == "Менять цвета")
            {
                timer1.Start();
                менятьЦветаToolStripMenuItem.Text = "Остановить";
            }
            else
            {
                менятьЦветаToolStripMenuItem.Text = "Менять цвета";
                timer1.Stop();
            }
        }
    }
}
